rest-calculator
===============

Simple RESTful calculator web application using Flask and jQuery

### Installation ###

  1. From inside the "rest-calculator" 
     run "pip install -r requirements.txt"
  2. set FLASK_APP = caluculator.py
  2. For running, $flask run
  3. Open a browser and go to http://127.0.0.1:5000
